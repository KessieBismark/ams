import 'package:fluent_ui/fluent_ui.dart';
import 'package:fluttericon/entypo_icons.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import '../../../manufacturing/inventory/invoices/invoices.dart';
import '../../../manufacturing/inventory/suppliers/suppliers.dart';
import '../../../services/utils/helpers.dart';

class SubMenu {
  final String id;
  final String title;
  final Widget widget;
  final IconData? icon;

  SubMenu(
      {required this.id,
      this.icon = Entypo.dot,
      required this.title,
      required this.widget});
}

class MenuModel {
  final String id;
  final String title;
  final String? label;
  final IconData icon;
  final Widget? widget;
  final List<SubMenu> subMenu;

  MenuModel(
      {required this.id,
      required this.title,
      this.label,
      required this.subMenu,
      required this.icon,
      this.widget});
}

class MenuHeader {
  final String header;
  final List<MenuModel> menus;

  MenuHeader({required this.header, required this.menus});

  static List<MenuHeader> data = [
    MenuHeader(header: "Inventory Management", menus: [
      MenuModel(
          id: Utils.getInitials('Supplies Info'),
          title: 'Supplies',
          icon: FontAwesomeIcons.clipboardList,
          subMenu: [
            SubMenu(
                icon: Entypo.dot,
                id: Utils.getInitials('Suppliers'),
                title: 'Suppliers',
                widget: const RawMaterial()),
            SubMenu(
                icon: Entypo.dot,
                id: Utils.getInitials('Purchase Orders'),
                title: 'Purchase Orders',
                widget: const RawMaterial()),
            SubMenu(
                icon: Entypo.dot,
                id: Utils.getInitials('Invoices'),
                title: 'Invoices',
                widget: const RawMaterial()),
            SubMenu(
                icon: Entypo.dot,
                id: Utils.getInitials('Materials'),
                title: 'Materials',
                widget: const RawMaterial()),
            SubMenu(
                icon: Entypo.dot,
                id: Utils.getInitials('Supplies Inventory'),
                title: 'Supplies Inventory',
                widget: const RawInventory())
          ]),
    ]),
    MenuHeader(header: "Production Management", menus: [
      MenuModel(
          id: Utils.getInitials('Production'),
          title: 'Production',
          icon: FontAwesomeIcons.flask,
          subMenu: [
            SubMenu(
                icon: Entypo.dot,
                id: Utils.getInitials('Raw Materials'),
                title: 'Raw Materials',
                widget: const RawMaterial())
          ]),
      MenuModel(
          id: Utils.getInitials('Raw Materials'),
          title: 'Raw Materials',
          icon: FontAwesomeIcons.flask,
          subMenu: [],
          widget: const RawMaterial())
    ])
  ];
}

class Cpy {
  bool cpySet = false;
 static String cpyName = '';
 static String cpyContact = '';
 static String cpyAddress = '';
 static String cpyGps = '';
static  String cpySlogan = '';
 static String cpyWebsite = '';
 static String cpyEmail = '';
}

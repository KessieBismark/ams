class DropDownModel {
  final String id;
  final String name;

  DropDownModel({required this.id, required this.name});
}

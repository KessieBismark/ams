class Api {
 // static const url = "https://plaza.royalfoamghana.com/server/query.php";
  static const url = "https://ams.royalfoamghana.com/server/query.php";
 // static const url = "http://localhost/ams/query.php";
  final Uri bistech = Uri.parse('https://bistechgh.com/');
  final Uri downloadLink = Uri.parse('https://bistechgh.com/');
}

// import 'package:flutter/material.dart';
// import 'package:select_searchable_list/select_searchable_list.dart';

// import '../utils/model.dart';

// class DropSelectable extends StatelessWidget {
//   final Function(List<DropDownModel>) onChange;
//   // final List<String> selected;
//   final List<DropDownModel> items;
//   final TextEditingController controller;

//   final String hint;
//   // final String Function(String?)? validate;
//   final bool isLoading;
//   const DropSelectable(
//       {super.key,
//       required this.onChange,
//       required this.items,
//       required this.hint,
//       required this.isLoading,
//       required this.controller});

//   @override
//   Widget build(BuildContext context) {
//     return DropDownTextField(
//         textEditingController: controller,
//         title: 'Em',
//         hint: hint,
//         options: items,
//         selectedOptions: _selectedCategory,
//         onChanged: onChange);
//   }
// }

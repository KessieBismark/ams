

// class KeyButton extends StatelessWidget {
//   const KeyButton({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: ()=> null,
//       child: FocusableActionDetector(
//         shortcuts: ,
//         child: ElevatedButton(child: "".toLabel(),)),
//     );
//   }
// }
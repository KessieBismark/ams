import 'package:fl/services/constants/color.dart';
import 'package:flutter/material.dart';
import 'package:fluent_ui/fluent_ui.dart' as fluent;
import 'package:get/get.dart';

import '../pages/layout/drawer.dart';
import '../pages/layout/responsive.dart';
import '../pages/layout/tab_panel.dart';

class MyHome extends StatelessWidget {
  const MyHome({super.key});

  @override
  Widget build(BuildContext context) {
    var showChat = false.obs;
    var isHovering = false.obs;
    return Scaffold(
      appBar: Responsive.isDesktop(context)
          ? null
          : AppBar(elevation: 1, backgroundColor: Colors.grey.withAlpha(200)),
      drawer: Responsive.isDesktop(context) ? null : const MyDrawer(),
      body: Stack(
        children: [
          fluent.Row(
            children: [
              Responsive.isDesktop(context)
                  ? const Expanded(child: MyDrawer())
                  : Container(),
              const Expanded(
                flex: 5,
                child: fluent.FluentApp(
                  debugShowCheckedModeBanner: false,
                  home: Home(),
                ),
              ),
            ],
          ),
          Obx(() => AnimatedPositioned(
                duration: const Duration(milliseconds: 200),
                curve: Curves.easeInOut,
                bottom: showChat.value ? 20 : -400,
                right: 70,
                child: AnimatedOpacity(
                  duration: const Duration(milliseconds: 200),
                  opacity: showChat.value ? 1.0 : 0.0,
                  child: Container(
                    height: 400,
                    width: 300,
                    decoration: BoxDecoration(
                      color: light,
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.5),
                          spreadRadius: 2,
                          blurRadius: 5,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Container(),
                  ),
                ),
              )),
        ],
      ),
      floatingActionButton: Obx(
        () => MouseRegion(
          onEnter: (event) {
            isHovering.value = true;
          },
          onExit: (event) {
            isHovering.value = false;
          },
          child: InkWell(
            onTap: () {
              showChat.value = !showChat.value;
            },
            child: Container(
              decoration: BoxDecoration(
                color: isHovering.value ? Colors.green : trans,
                borderRadius: BorderRadius.circular(50.0),
              ),
              padding: const EdgeInsets.all(10.0),
              child: Icon(
                Icons.chat,
                color: isHovering.value ? Colors.white : Colors.green,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

  // void _closeDrawer(context) {
  //   Navigator.of(context).pop();
  // }